$(document).ready(function(){

    //역할 팝업
    $(".go").click(function(){
        $(".role").show();
      });
      $(".clo").click(function(){
          $(".role").hide();
      });
    
    //룰 팝업
    $(".ru").click(function(){
        $(".rule").show();
      });
      $(".clo").click(function(){
          $(".rule").hide();
      });

      
});``